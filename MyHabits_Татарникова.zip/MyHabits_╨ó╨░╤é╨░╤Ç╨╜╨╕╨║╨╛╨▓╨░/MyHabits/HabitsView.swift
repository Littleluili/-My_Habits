//
//  HabitsView.swift
//  MyHabits
//
//  Created by Elizaveta on 22.11.2020.
//  Copyright © 2020 Elizaveta. All rights reserved.
//

import UIKit

class HabitsView: UIView {


    private var addButton: UIButton = {
        let button = UIButton()
        button.addTarget(self, action: #selector(addHabitButton), for: .touchUpInside)
        return button
    }()

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(addButton)
       // addButton.translatesAutoresizingMaskIntoConstraints = false
    }

    
    required init?(coder: NSCoder) {
           super.init(coder: coder)
       }
    
    @objc func addHabitButton() {
        print("its ok")
    }
}
